package com.wearemagic.lasalle.one.exceptions;

public class LoginTimeoutException extends Exception{
}
